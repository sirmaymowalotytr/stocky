const { Client, GatewayIntentBits, EmbedBuilder, SlashCommandBuilder, REST, Routes, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');
const express = require('express');
const config = require('./config.json');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages] });
const dataFile = path.join(__dirname, 'data.json');
let userData = JSON.parse(fs.readFileSync(dataFile, 'utf8'));

const stocks = {
    'AAPL': 150,
    'GOOGL': 2800,
    'AMZN': 3500,
    'TSLA': 700,
    'MSFT': 290
};

const businesses = {
    'Lemonade Stand': { price: 100, income: 10 },
    'Coffee Shop': { price: 1000, income: 100 },
    'Tech Startup': { price: 10000, income: 1000 }
};

const startingBalance = 10000;
const workIncome = 100;
const businessClaimInterval = 21600000; // 6 hours in milliseconds
const priceChangeInterval = 60000; // Update prices every minute

function saveData() {
    try {
        fs.writeFileSync(dataFile, JSON.stringify(userData, null, 2));
    } catch (error) {
        console.error('Error saving data:', error);
    }
}

function updatePrices() {
    for (let stock in stocks) {
        const change = (Math.random() - 0.5) * 20; // Random change between -10 and +10
        stocks[stock] = Math.max(1, stocks[stock] + change); // Ensure price doesn't go below 1
    }
}

function createEmbed(title, description, color = 0x00AE86, imageUrl = null) {
    const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(color)
        .setTimestamp();
    if (imageUrl) embed.setImage(imageUrl);

    return embed;
}

function getUserData(userId) {
    if (!userData[userId]) {
        userData[userId] = {
            balance: startingBalance,
            portfolio: {},
            businesses: {},
            achievements: [],
            notifications: true,
            lastClaimed: 0
        };
        saveData();
    }
    return userData[userId];
}

function getUserPortfolioValue(user) {
    let totalValue = 0;
    for (const stock in user.portfolio) {
        totalValue += stocks[stock] * user.portfolio[stock];
    }
    return totalValue;
}

// Slash commands registration
const commands = [
    new SlashCommandBuilder().setName('balance').setDescription('Check your current balance'),
    new SlashCommandBuilder().setName('buy')
        .setDescription('Buy stocks')
        .addStringOption(option => option.setName('stock').setDescription('Stock symbol').setRequired(true))
        .addIntegerOption(option => option.setName('amount').setDescription('Amount to buy').setRequired(true)),
    new SlashCommandBuilder().setName('sell')
        .setDescription('Sell stocks')
        .addStringOption(option => option.setName('stock').setDescription('Stock symbol').setRequired(true))
        .addIntegerOption(option => option.setName('amount').setDescription('Amount to sell').setRequired(true)),
    new SlashCommandBuilder().setName('prices').setDescription('Check current stock prices'),
    new SlashCommandBuilder().setName('portfolio').setDescription('View your stock portfolio'),
    new SlashCommandBuilder().setName('leaderboard').setDescription('View the wealthiest players'),
    new SlashCommandBuilder().setName('trade')
        .setDescription('Trade stocks with other players')
        .addUserOption(option => option.setName('user').setDescription('User to trade with').setRequired(true))
        .addStringOption(option => option.setName('stock').setDescription('Stock symbol').setRequired(true))
        .addIntegerOption(option => option.setName('amount').setDescription('Amount to trade').setRequired(true)),
    new SlashCommandBuilder().setName('casino').setDescription('Try your luck in the casino'),
    new SlashCommandBuilder().setName('invest').setDescription('Invest in the stock market'),
    new SlashCommandBuilder().setName('notify').setDescription('Toggle notifications'),
    new SlashCommandBuilder().setName('achievements').setDescription('View your achievements'),
    new SlashCommandBuilder().setName('work').setDescription('Work to earn money when you are broke'),
    new SlashCommandBuilder().setName('business')
        .setDescription('Buy and manage businesses')
        .addStringOption(option => option.setName('action').setDescription('Action to perform').setRequired(true).addChoices(
            { name: 'buy', value: 'buy' },
            { name: 'claim', value: 'claim' },
            { name: 'list', value: 'list' }
        ))
        .addStringOption(option => option.setName('business').setDescription('Business name').setRequired(false))
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(config.token);

(async () => {
    try {
        console.log('Started refreshing application (/) commands.');

        await rest.put(
            Routes.applicationCommands(config.clientId),
            { body: commands }
        );

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error('Error reloading application (/) commands:', error);
    }
})();

// Event listeners
client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
    setInterval(updatePrices, priceChangeInterval); // Update stock prices periodically
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const { commandName } = interaction;
    const userId = interaction.user.id;

    try {
        if (commandName === 'balance') {
            const user = getUserData(userId);
            const portfolioValue = getUserPortfolioValue(user);
            const embed = createEmbed('Current Balance', `You have $${user.balance.toFixed(2)}\nPortfolio Value: $${portfolioValue.toFixed(2)}`, 0x00FF00);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'buy') {
            const stock = interaction.options.getString('stock').toUpperCase();
            const amount = interaction.options.getInteger('amount');
            const user = getUserData(userId);

            if (!stocks[stock]) {
                await interaction.reply({ content: `Stock ${stock} does not exist.`, ephemeral: true });
                return;
            }

            const cost = stocks[stock] * amount;
            if (user.balance < cost) {
                await interaction.reply({ content: `You do not have enough money to buy ${amount} shares of ${stock}.`, ephemeral: true });
                return;
            }

            user.balance -= cost;
            user.portfolio[stock] = (user.portfolio[stock] || 0) + amount;
            saveData();

            const embed = createEmbed('Stock Purchase', `Bought ${amount} shares of ${stock} for $${cost.toFixed(2)}`, 0x0000FF);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'sell') {
            const stock = interaction.options.getString('stock').toUpperCase();
            const amount = interaction.options.getInteger('amount');
            const user = getUserData(userId);

            if (!user.portfolio[stock] || user.portfolio[stock] < amount) {
                await interaction.reply({ content: `You do not have ${amount} shares of ${stock} to sell.`, ephemeral: true });
                return;
            }

            const earnings = stocks[stock] * amount;
            user.balance += earnings;
            user.portfolio[stock] -= amount;
            if (user.portfolio[stock] === 0) delete user.portfolio[stock];
            saveData();

            const embed = createEmbed('Stock Sale', `Sold ${amount} shares of ${stock} for $${earnings.toFixed(2)}`, 0xFF0000);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'prices') {
            const priceList = Object.entries(stocks).map(([stock, price]) => `${stock}: $${price.toFixed(2)}`).join('\n');
            const embed = createEmbed('Current Stock Prices', priceList, 0x00FF00);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'portfolio') {
            const user = getUserData(userId);
            const portfolioList = Object.entries(user.portfolio).map(([stock, amount]) => `${stock}: ${amount} shares`).join('\n') || 'Your portfolio is empty.';
            const embed = createEmbed('Your Portfolio', portfolioList, 0x00FF00);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'leaderboard') {
            const leaderboard = Object.entries(userData).sort(([, a], [, b]) => (b.balance + getUserPortfolioValue(b)) - (a.balance + getUserPortfolioValue(a)))
                .slice(0, 10)
                .map(([id, user], index) => `${index + 1}. <@${id}>: $${(user.balance + getUserPortfolioValue(user)).toFixed(2)}`)
                .join('\n');
            const embed = createEmbed('Leaderboard', leaderboard, 0xFFD700);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'trade') {
            const targetUser = interaction.options.getUser('user').id;
            const stock = interaction.options.getString('stock').toUpperCase();
            const amount = interaction.options.getInteger('amount');
            const user = getUserData(userId);
            const target = getUserData(targetUser);

            if (!user.portfolio[stock] || user.portfolio[stock] < amount) {
                await interaction.reply({ content: `You do not have ${amount} shares of ${stock} to trade.`, ephemeral: true });
                return;
            }

            user.portfolio[stock] -= amount;
            if (user.portfolio[stock] === 0) delete user.portfolio[stock];
            target.portfolio[stock] = (target.portfolio[stock] || 0) + amount;
            saveData();

            const embed = createEmbed('Stock Trade', `Traded ${amount} shares of ${stock} with <@${targetUser}>`, 0x00FF00);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'casino') {
            const user = getUserData(userId);
            const bet = Math.min(100, user.balance);
            const multiplier = Math.random() < 0.5 ? 0 : Math.random() < 0.75 ? 2 : 5;

            if (bet === 0) {
                await interaction.reply({ content: 'You have no money to bet.', ephemeral: true });
                return;
            }

            user.balance -= bet;
            user.balance += bet * multiplier;
            saveData();

            const result = multiplier === 0 ? 'You lost!' : `You won $${(bet * multiplier).toFixed(2)}!`;
            const embed = createEmbed('Casino Result', result, multiplier === 0 ? 0xFF0000 : 0x00FF00);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'invest') {
            // Implement investment logic here

        } else if (commandName === 'notify') {
            const user = getUserData(userId);
            user.notifications = !user.notifications;
            saveData();

            const status = user.notifications ? 'enabled' : 'disabled';
            const embed = createEmbed('Notifications', `Notifications have been ${status}.`, 0x00FF00);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'achievements') {
            const user = getUserData(userId);
            const achievementsList = user.achievements.join('\n') || 'No achievements yet.';
            const embed = createEmbed('Your Achievements', achievementsList, 0x00FF00);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'work') {
            const user = getUserData(userId);

            if (user.balance > 0) {
                await interaction.reply({ content: 'You can only work when your balance is zero.', ephemeral: true });
                return;
            }

            user.balance += workIncome;
            saveData();

            const embed = createEmbed('Work', `You worked and earned $${workIncome}.`, 0x00FF00);
            await interaction.reply({ embeds: [embed] });

        } else if (commandName === 'business') {
            const action = interaction.options.getString('action');
            const business = interaction.options.getString('business');
            const user = getUserData(userId);

            if (action === 'buy') {
                if (!businesses[business]) {
                    await interaction.reply({ content: `Business ${business} does not exist.`, ephemeral: true });
                    return;
                }

                if (user.balance < businesses[business].price) {
                    await interaction.reply({ content: `You do not have enough money to buy ${business}.`, ephemeral: true });
                    return;
                }

                user.balance -= businesses[business].price;
                user.businesses[business] = (user.businesses[business] || 0) + 1;
                saveData();

                const embed = createEmbed('Business Purchase', `Bought ${business} for $${businesses[business].price}.`, 0x00FF00);
                await interaction.reply({ embeds: [embed] });

            } else if (action === 'claim') {
                const now = Date.now();
                if (now - user.lastClaimed < businessClaimInterval) {
                    await interaction.reply({ content: 'You can only claim earnings once every 6 hours.', ephemeral: true });
                    return;
                }

                let totalEarnings = 0;
                for (const business in user.businesses) {
                    totalEarnings += user.businesses[business] * businesses[business].income;
                }

                user.balance += totalEarnings;
                user.lastClaimed = now;
                saveData();

                const embed = createEmbed('Business Earnings', `Claimed $${totalEarnings} from your businesses.`, 0x00FF00);
                await interaction.reply({ embeds: [embed] });

            } else if (action === 'list') {
                const businessList = Object.entries(businesses).map(([name, info]) => `${name}: $${info.price} (Income: $${info.income}/6h)`).join('\n');
                const embed = createEmbed('Available Businesses', businessList, 0x00FF00);
                await interaction.reply({ embeds: [embed] });
            }
        }
    } catch (error) {
        console.error('Error executing command:', error);
        await interaction.reply({ content: 'There was an error executing this command.', ephemeral: true });
    }
});

// Web server for status monitoring
const app = express();
const port = config.port || 3003;

app.get('/', (req, res) => {
    res.send('Bot is running');
});

app.listen(port, () => {
    console.log(`Web server running on port ${port}`);
});

app.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`Port ${port} is already in use`);
        app.listen(0, () => {
            console.log(`Web server running on a different port`);
        });
    }
});

client.login(config.token);
